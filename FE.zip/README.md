To Getting Started with Create React App
This project was bootstrapped with Create React App.

Available Scripts
In the project directory, you can run:

npm run start-dev
Runs the app in the development mode.
Open http://localhost:3000 to view it in your browser.

npm start
build and gets started in production

The page will reload when you make changes.
You may also see any lint errors in the console.

FE : https://tbss-fe.herokuapp.com/
BE : https://tbss-be.herokuapp.com/

Test Credentials
user : abhijeet@gmail.com
password : 12345678
