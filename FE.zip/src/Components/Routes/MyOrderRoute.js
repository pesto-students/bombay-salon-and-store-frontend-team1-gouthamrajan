import React from 'react'
import MyOrder from '../MyOrder/MyOrder'

const MyOrderRoute = () => {
  return (
    <MyOrder />
  )
}

export default MyOrderRoute