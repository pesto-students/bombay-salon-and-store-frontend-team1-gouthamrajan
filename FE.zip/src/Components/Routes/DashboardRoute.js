import React from 'react'
import Home from '../Home/Home'

const DashboardRoute = () => {
  return (
    <Home />
  )
}

export default DashboardRoute