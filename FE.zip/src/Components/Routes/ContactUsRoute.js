import React from 'react'
import ContactUs from '../ContactUs/ContactUs'

const ContactUsRoute = () => {
  return (
    <ContactUs />
  )
}

export default ContactUsRoute