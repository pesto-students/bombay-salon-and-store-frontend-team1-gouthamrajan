import React from "react";
import OrderPlaced from "../OrderPlaced/OrderPlaced";

const OrderPlacedRoute = () => {
  return <OrderPlaced />;
};

export default OrderPlacedRoute;
