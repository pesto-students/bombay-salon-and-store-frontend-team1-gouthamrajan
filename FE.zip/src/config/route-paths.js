const routePaths = {
  index: "/",
  myOrders: "my-orders",
  contactUs: "contact-us",
  resetPassword: "recover-password/:token",
  orderPlaced: "order-placed/:type/:id",
};

export default routePaths;
