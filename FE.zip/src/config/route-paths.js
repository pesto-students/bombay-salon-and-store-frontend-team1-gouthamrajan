const routePaths = {
  index: "/",
  resetPassword: "recover-password/:token",
  orderPlaced: "order-placed/:id",
};

export default routePaths;
